import os
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QProgressBar, QComboBox, QFileDialog, QTextEdit, QLineEdit
from qgis.core import QgsProject, QgsVectorLayer
import xlsxwriter
from unidecode import unidecode
from PyQt5.QtCore import QDate, QDateTime


class validar_gpkg(QDialog):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.setWindowTitle("Validar Datos GPKG")
        self.resize(500, 400)

        # Layout principal
        layout = QVBoxLayout()

        # ComboBox para seleccionar la capa
        self.layer_combo = QComboBox()
        layout.addWidget(QLabel("Seleccionar capa para validar:"))
        layout.addWidget(self.layer_combo)

        # Campo para seleccionar la ruta de guardado del archivo Excel
        self.path_input = QLineEdit()
        self.path_input.setPlaceholderText("Ruta de guardado del reporte...")
        layout.addWidget(self.path_input)

        # Botón para seleccionar la ruta de guardado
        self.browse_button = QPushButton("Explorar")
        layout.addWidget(self.browse_button)

        # Botón para validar
        self.validate_button = QPushButton("Validar")
        layout.addWidget(self.validate_button)

        # Barra de progreso
        self.progress_bar = QProgressBar()
        layout.addWidget(self.progress_bar)

        # Cuadro de texto para mostrar el progreso de la validación
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        layout.addWidget(self.log_text)

        # Conectar eventos a funciones
        self.browse_button.clicked.connect(self.select_save_path)
        self.validate_button.clicked.connect(self.run_validation)

        # Cargar capas cargadas en QGIS
        self.load_layers()

        self.setLayout(layout)

    def load_layers(self):
        """Cargar las capas vectoriales de QGIS en el comboBox."""
        self.layer_combo.clear()
        layers = [layer for layer in QgsProject.instance().mapLayers().values() if isinstance(layer, QgsVectorLayer)]
        for layer in layers:
            self.layer_combo.addItem(layer.name())

    def select_save_path(self):
        """Abrir un diálogo para seleccionar la ruta de guardado del archivo Excel."""
        save_path, _ = QFileDialog.getSaveFileName(self, "Guardar reporte de validación", "", "Excel Files (*.xlsx)")
        if save_path:
            self.path_input.setText(save_path)






    def run_validation(self):
        """Función principal para ejecutar la validación y generar el reporte en Excel."""
        selected_layer_name = self.layer_combo.currentText()
        layers = QgsProject.instance().mapLayersByName(selected_layer_name)
        if not layers:
            self.iface.messageBar().pushWarning("Advertencia", "No se encontró la capa seleccionada.")
            return

        layer = layers[0]  # Obtener la capa seleccionada

        save_path = self.path_input.text()
        if not save_path:
            self.iface.messageBar().pushWarning("Advertencia", "Por favor selecciona la ruta de guardado del archivo.")
            return

        # Configurar Excel
        try:
            workbook = xlsxwriter.Workbook(save_path)
        except Exception as e:
            self.iface.messageBar().pushWarning("Error", f"No se pudo crear el archivo Excel: {str(e)}")
            return

        worksheet = workbook.add_worksheet()

        # Escribir los encabezados
        headers = ["QR", "QR_CONTENEDOR", "DTO", "MUNI", "UIT", "TIPO_DERECHO", "FORMAL_INFORMAL", "COD_DANE","F_LEV","F_REPOR","AREA_M2","AREA_HA", "VALIDACION_DERECHO_TIPO","VALIDACION_COINCIDENCIA_QRs"]
        for col_num, header in enumerate(headers):
            worksheet.write(0, col_num, header)

        # Barra de progreso
        self.progress_bar.setMaximum(layer.featureCount())

        row = 1
        for i, feature in enumerate(layer.getFeatures()):
            # Convertir valores a minúsculas y eliminar tildes para hacer comparaciones insensibles a mayúsculas, minúsculas y tildes
            tipo_derecho = unidecode(str(feature["TIPO_DERECHO"]).strip().lower()) if feature["TIPO_DERECHO"] else ""
            formal_informal = unidecode(str(feature["FORMAL_INFORMAL"]).strip().lower()) if feature["FORMAL_INFORMAL"] else ""


            # Validación de TIPO_DERECHO y FORMAL_INFORMAL
            validation_result = ""

            # Regla 1: Si TIPO_DERECHO es 'dominio' y FORMAL_INFORMAL es 'informal'
            if tipo_derecho in ['dominio'] and formal_informal in ['informal']:
                validation_result = 'ERROR, UN DOMINIO NO PUEDE SER INFORMAL'
            
            # Regla 2: Si TIPO_DERECHO es posesión u ocupación y FORMAL_INFORMAL es 'formal'
            elif tipo_derecho in ['ocupacion', 'posesion'] and formal_informal in ['formal', 'bien_uso_publico', 'formal ospr', 'formal_ospr','formal_con_remanente', 'formal_remanente', 'formal_sin_remanente']:
                validation_result = 'ERROR, POSESION/OCUPACION NO PUEDE SER FORMAL'
            
            # Regla 3: Si TIPO_DERECHO está vacío o nulo
            elif not tipo_derecho or tipo_derecho == 0 or tipo_derecho.strip() == "":
                validation_result = 'FALTA DILIGENCIAR TIPO_DERECHO'
            
            # Regla 4: Si FORMAL_INFORMAL está vacío o nulo
            elif not formal_informal or formal_informal == 0 or formal_informal.strip() == "":
                validation_result = 'FALTA DILIGENCIAR FORMAL_INFORMAL (CONDICION DEL PREDIO)'
            
            # Regla 5: Si TIPO_DERECHO es posesión u ocupación e INFORMAL está bien
            elif tipo_derecho in ['ocupacion', 'posesion'] and formal_informal in ['informal']:
                validation_result = 'OK_INFORMAL'
            
            # Regla 6: Si TIPO_DERECHO es dominio y FORMAL está bien
            elif tipo_derecho in ['dominio'] and formal_informal in ['formal', 'bien_uso_publico', 'formal ospr', 'formal_con_remanente', 'formal_remanente', 'formal_sin_remanente']:
                validation_result = 'OK_FORMAL'
            
            # Si ninguna regla aplica
            else:
                validation_result = 'VERIFICAR MANUALMENTE QUE PASA'


            # Validación de coincidencia de QR y QR_CONTENEDOR
            qr = feature["QR"]
            qr_contenedor = feature["QR_CONTENEDOR"]
            coincidencia_qr_result = ""

            if qr == qr_contenedor:
                coincidencia_qr_result = 'DEBERÍA SER FORMAL'
            elif qr != qr_contenedor:
                coincidencia_qr_result = 'DEBERÍA SER INFORMAL'
            elif qr is None:
                coincidencia_qr_result = 'FALTA QR'
            elif qr_contenedor is None or qr_contenedor == 0:
                coincidencia_qr_result = 'FALTA QR MATRIZ'




            # Convertir el valor de F_LEV a formato dd/mm/yyyy
            f_lev = self.format_date(feature["F_LEV"])

            # Convertir el valor de F_REPOR a formato dd/mm/yyyy
            f_repor = self.format_date(feature["F_REPOR"])


            # Calcular el área en hectáreas (dividir AREA_M2 por 10,000) y redondear a 2 decimales
            area_m2 = float(feature["AREA_M2"]) if feature["AREA_M2"] else 0
            area_ha = round(area_m2 / 10000, 4)  # Redondear a 2 decimales


            # Escribir los resultados en el archivo Excel y manejar valores nulos
            worksheet.write(row, 0, self.safe_write(feature["QR"]))
            worksheet.write(row, 1, self.safe_write(feature["QR_CONTENEDOR"]))
            worksheet.write(row, 2, self.safe_write(feature["DTO"]))
            worksheet.write(row, 3, self.safe_write(feature["MUNI"]))
            worksheet.write(row, 4, self.safe_write(feature["UIT"]))
            worksheet.write(row, 5, self.safe_write(tipo_derecho))
            worksheet.write(row, 6, self.safe_write(formal_informal))
            worksheet.write(row, 7, self.safe_write(feature["COD_DANE"]))
            worksheet.write(row, 8, self.safe_write(f_lev))
            worksheet.write(row, 9, self.safe_write(f_repor)) 
            worksheet.write(row, 10, self.safe_write(feature["AREA_M2"]))
            worksheet.write(row, 11, self.safe_write(area_ha))
            worksheet.write(row, 12, validation_result)
            worksheet.write(row, 13, coincidencia_qr_result) 

            # Actualizar el cuadro de progreso
            self.progress_bar.setValue(i + 1)
            # Mostrar el QR y resultado de validación en el cuadro de texto
            self.log_text.append(f"Validando QR: {feature['QR']} -> {validation_result if validation_result else 'Válido'}")

            row += 1

        # Guardar y cerrar el archivo Excel
        workbook.close()

        # Mostrar mensaje de éxito
        self.iface.messageBar().pushSuccess("Éxito", f"Validación completada. Archivo guardado en {save_path}")


    def format_date(self, date_value):
        """Función para formatear la fecha en formato dd/mm/yyyy."""
        try:
            if isinstance(date_value, QDate):  # Si es un QDate
                return date_value.toString('dd/MM/yyyy')
            elif isinstance(date_value, QDateTime):  # Si es un QDateTime
                return date_value.date().toString('dd/MM/yyyy')
            elif isinstance(date_value, str):  # Si es una cadena de texto
                return datetime.strptime(date_value.strip(), '%Y-%m-%d').strftime('%d/%m/%Y')
            elif isinstance(date_value, (int, float)):  # Para fechas numéricas
                origin = datetime(1900, 1, 1)
                return (origin + timedelta(days=int(date_value))).strftime('%d/%m/%Y')
        except Exception:
            # Si falla la conversión, retornar el valor original
            return date_value


    def safe_write(self, value):
        """Función para evitar errores al escribir valores no válidos en Excel."""
        if value is None or str(value).strip() == "":
            return ""
        return str(value)
