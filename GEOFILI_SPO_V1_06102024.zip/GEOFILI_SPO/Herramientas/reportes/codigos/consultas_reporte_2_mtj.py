# consultas_reporte_observaciones.py

consultas_reporte_2_mtj = [
    """

    ----------------- 18.1 Area de Levantamiento en Base de datos coincide con area MTJ

    SELECT 
        COALESCE(pd.qr_operacion, mtj.id_operacion) AS qr_operacion,
        pd.qr_operacion as "QR_MATRIZ (CODIGO_NIVEL) BD",
        ccp.ilicode as "CONDICION_PREDIO BD",
        pd.qr_operacion_definitivo AS "QR_DERIVADO (ID_OPERACION) BD" ,

        ROUND((ST_Area(ST_Transform(te.geometria, 9377))::numeric), 2) as "ÁREA LEVANTAMIENTO (m2) BD",
        mtj.local_id as "QR_MATRIZ (CODIGO_NIVEL) MTJ",
        mtj.id_operacion AS "QR_DERIVADO (ID_OPERACION) MTJ",
        mtj.condicion_predio as "CONDICION PREDIO MTJ",
        
            ((REPLACE(mtj.area_terreno_levantamiento, ',', '.'))::numeric) as "ÁREA LEVANTAMIENTO (m2) MTJ",
        CASE 
            WHEN  ((REPLACE(mtj.area_terreno_levantamiento, ',', '.'))::numeric)=  ROUND((ST_Area(ST_Transform(te.geometria, 9377))::numeric), 2) then 'SI' ELSE 'NO' END AS "COINCIDE(SI/NO) AREA_LEV"
            
        ,ABS(ROUND((ST_Area(ST_Transform(te.geometria, 9377))::numeric), 2) - ((REPLACE(mtj.area_terreno_levantamiento, ',', '.'))::numeric)) as "DIFERENCIA_AREAS",
        CASE
            WHEN (ABS(((REPLACE(mtj.area_terreno_levantamiento, ',', '.'))::numeric) - ROUND((ST_Area(ST_Transform(te.geometria, 9377))::numeric), 2)) > 0.005) 
            OR  (ABS(((REPLACE(mtj.area_terreno_levantamiento, ',', '.'))::numeric) - ROUND((ST_Area(ST_Transform(te.geometria, 9377))::numeric), 2)) > 0.005) IS NULL THEN 'AJUSTAR' ELSE 'OK' END AS "VALIDACION"
        ,CASE
            WHEN pd.qr_operacion_definitivo IS NULL THEN 'Falta en cca_predio'
            WHEN mtj.id_operacion IS NULL THEN 'Falta en matriz_mtj'
            ELSE NULL
        END AS "OBS"
    FROM 
        {esquema}.cca_predio pd
    JOIN {esquema}.cca_condicionprediotipo ccp ON pd.condicion_predio = ccp.t_id  
    FULL OUTER JOIN 
        {esquema}.cca_terreno te ON pd.terreno = te.t_id
    FULL OUTER JOIN 
        mtj.matriz_mtj mtj ON pd.qr_operacion_definitivo = mtj.id_operacion
        
    WHERE 
        (ABS(((REPLACE(mtj.area_terreno_levantamiento, ',', '.'))::numeric) - ROUND((ST_Area(ST_Transform(te.geometria, 9377))::numeric), 2)) > 0.05)
        OR  (ABS(((REPLACE(mtj.area_terreno_levantamiento, ',', '.'))::numeric) - ROUND((ST_Area(ST_Transform(te.geometria, 9377))::numeric), 2)) > 0.05) IS NULL



    """,
    
    
    """
    
    ----18.2	Area  y numero de construcciones coincide Base de Datos  MTJ
    WITH bd_data AS (
        SELECT 
            cp.qr_operacion AS "QR_MATRIZ (CODIGO_NIVEL) BD", 
            cp.qr_operacion_definitivo AS "QR_DERIVADO (ID_OPERACION) BD", 
            ccp.ilicode AS "CONDICION_PREDIO_BD",
            CASE 
                WHEN EXISTS (SELECT 1 FROM {esquema}.cca_caracteristicasunidadconstruccion cc WHERE cc.predio = cp.t_id) THEN 'SI' 
                ELSE 'NO'
            END AS "¿TIENE CONSTRUCCIONES? BD", 
            (SELECT count(*) FROM {esquema}.cca_caracteristicasunidadconstruccion cc WHERE cc.predio = cp.t_id) AS "¿CANTIDAD CONSTRUCCIONES? BD",
            (SELECT ROUND(SUM(ST_Area(ST_Transform(cu.geometria, 9377))::numeric), 2)
            FROM {esquema}.cca_unidadconstruccion cu 
            JOIN {esquema}.cca_caracteristicasunidadconstruccion cca ON cca.t_id = cu.caracteristicasunidadconstruccion 
            WHERE cca.predio = cp.t_id
            ) AS "ÁREA TOTAL CONSTRUIDA (m2) BD"	
        FROM {esquema}.cca_predio cp 
        JOIN {esquema}.cca_terreno ct ON cp.terreno = ct.t_id 
        JOIN {esquema}.cca_derecho cd ON cp.t_id = cd.predio 
        JOIN {esquema}.cca_derechotipo cdt ON cd.tipo = cdt.t_id 
        JOIN {esquema}.cca_condicionprediotipo ccp ON cp.condicion_predio = ccp.t_id 
        JOIN {esquema}.cca_fuenteadministrativa cfa ON cd.t_id = cfa.derecho 
        JOIN {esquema}.cca_fuenteadministrativatipo cfat ON cfa.tipo = cfat.t_id 
        JOIN {esquema}.cca_destinacioneconomicatipo cdet ON cp.destinacion_economica = cdet.t_id 
        GROUP BY 
            cp.qr_operacion, cp.qr_operacion_definitivo, ccp.ilicode, cp.t_id, ct.geometria
    ),
    mtj_data AS (
        SELECT 
            local_id AS "QR_MATRIZ (CODIGO_NIVEL) MTJ", 
            id_operacion AS "QR_DERIVADO (ID_OPERACION) MTJ", 
            condicion_predio AS "CONDICION_PREDIO_MTJ", 
            tiene_construcciones AS "¿TIENE CONSTRUCCIONES? MTJ", 
            cons_cantidad AS "¿CANTIDAD CONSTRUCCIONES? MTJ",
            CASE 
                WHEN TRIM(cons_area) = '' THEN '0'
                ELSE REPLACE(cons_area, ',', '.') 
            END AS "ÁREA TOTAL CONSTRUIDA (m2) MTJ"
        FROM mtj.matriz_mtj
    )
    SELECT 
        bd."QR_MATRIZ (CODIGO_NIVEL) BD",
        bd."QR_DERIVADO (ID_OPERACION) BD",
        bd."CONDICION_PREDIO_BD",
        bd."¿TIENE CONSTRUCCIONES? BD",
        bd."¿CANTIDAD CONSTRUCCIONES? BD",
        bd."ÁREA TOTAL CONSTRUIDA (m2) BD",
        mtj."QR_MATRIZ (CODIGO_NIVEL) MTJ",
        mtj."QR_DERIVADO (ID_OPERACION) MTJ",
        mtj."CONDICION_PREDIO_MTJ",  
        mtj."¿TIENE CONSTRUCCIONES? MTJ",
        mtj."¿CANTIDAD CONSTRUCCIONES? MTJ",
        mtj."ÁREA TOTAL CONSTRUIDA (m2) MTJ",
        CASE 
            WHEN bd."¿TIENE CONSTRUCCIONES? BD" = mtj."¿TIENE CONSTRUCCIONES? MTJ" THEN 'SI' 
            WHEN bd."¿TIENE CONSTRUCCIONES? BD" IS NULL OR mtj."¿TIENE CONSTRUCCIONES? MTJ" IS NULL THEN 'FALTAN DATOS'
            ELSE 'NO' 
        END AS "COINCIDE(SI/NO) TIENE_CONS",
        CASE 
            WHEN (bd."¿CANTIDAD CONSTRUCCIONES? BD"::TEXT = mtj."¿CANTIDAD CONSTRUCCIONES? MTJ"::TEXT) OR  (bd."¿CANTIDAD CONSTRUCCIONES? BD"=0 AND mtj."¿CANTIDAD CONSTRUCCIONES? MTJ" IS NULL)  THEN 'SI'
            WHEN bd."¿CANTIDAD CONSTRUCCIONES? BD" IS NULL OR mtj."¿CANTIDAD CONSTRUCCIONES? MTJ" IS NULL THEN 'FALTAN DATOS'
            ELSE 'NO' 
        END AS "COINCIDE(SI/NO) CANTIDAD_CONS",	     
        CASE 
            WHEN bd."ÁREA TOTAL CONSTRUIDA (m2) BD"::numeric = COALESCE(NULLIF(REGEXP_REPLACE(REPLACE(mtj."ÁREA TOTAL CONSTRUIDA (m2) MTJ", ',', '.'), '[^0-9.]', '', 'g'), '')::numeric, 0) 
            or bd."ÁREA TOTAL CONSTRUIDA (m2) BD" IS NULL AND mtj."ÁREA TOTAL CONSTRUIDA (m2) MTJ" IS NULL THEN 'SI' 
            ELSE 'NO' 
        END AS "COINCIDE(SI/NO) AREA_CONSTRUIDA (m2)",

    ABS(bd."ÁREA TOTAL CONSTRUIDA (m2) BD"::numeric - COALESCE(NULLIF(REGEXP_REPLACE(REPLACE(mtj."ÁREA TOTAL CONSTRUIDA (m2) MTJ", ',', '.'), '[^0-9.]', '', 'g'), '')::numeric, 0)) AS "DIFERENCIA AREAS",

        CASE 
            WHEN ABS(bd."ÁREA TOTAL CONSTRUIDA (m2) BD"::numeric - COALESCE(NULLIF(REGEXP_REPLACE(REPLACE(mtj."ÁREA TOTAL CONSTRUIDA (m2) MTJ", ',', '.'), '[^0-9.]', '', 'g'), '')::numeric, 0)) > 0.05 THEN 'Ajustar, difiere área'
            
            WHEN (bd."ÁREA TOTAL CONSTRUIDA (m2) BD" is NULL and mtj."ÁREA TOTAL CONSTRUIDA (m2) MTJ" IS NOT NULL) THEN 'Se tiene información de área en MTJ que no está en la BD'
            WHEN (bd."ÁREA TOTAL CONSTRUIDA (m2) BD" is NOT NULL and mtj."ÁREA TOTAL CONSTRUIDA (m2) MTJ" IS NULL) THEN 'Se tiene información de área en la BD que no está en la MTJ'
            
            ELSE 'OK'
        END AS "VALIDACION CONST"


    FROM bd_data bd
    FULL OUTER JOIN mtj_data mtj 
    ON bd."QR_DERIVADO (ID_OPERACION) BD" = mtj."QR_DERIVADO (ID_OPERACION) MTJ"
    WHERE bd."QR_DERIVADO (ID_OPERACION) BD" IS NOT NULL OR mtj."QR_DERIVADO (ID_OPERACION) MTJ" IS NOT NULL;



    """,
    """
    ---- 19 - Coindicencia Fuente administrativa Base de Datos - MTJ

    WITH bd_data AS (
        SELECT 
            cp.qr_operacion AS "QR_MATRIZ (CODIGO_NIVEL) BD", 
            cp.qr_operacion_definitivo AS "QR_DERIVADO (ID_OPERACION) BD",
            cfa.t_id as "T_ID CCA_FUENTEADM BD",
            ccp.ilicode AS "CONDICION_PREDIO_BD", cfat.ilicode as "TIPO FUENTE ADMINISTRATIVA BD",
            cfat.t_id as "T_ID_TIPO_FUENTE BD",
            cfa.ente_emisor as "ENTE EMISOR FUENTE ADMINISTRATIVA BD" , cfa.numero_fuente as "NÚMERO FUENTE ADMINISTRATIVA BD", 
            TO_CHAR(cfa.fecha_documento_fuente, 'DD/MM/YYYY') AS "FECHA FUENTE ADMINISTRATIVA BD"

        
        FROM {esquema}.cca_predio cp 
        JOIN {esquema}.cca_terreno ct ON cp.terreno = ct.t_id 
        JOIN {esquema}.cca_derecho cd ON cp.t_id = cd.predio 
        JOIN {esquema}.cca_derechotipo cdt ON cd.tipo = cdt.t_id 
        JOIN {esquema}.cca_condicionprediotipo ccp ON cp.condicion_predio = ccp.t_id 
        JOIN {esquema}.cca_fuenteadministrativa cfa ON cd.t_id = cfa.derecho 
        JOIN {esquema}.cca_fuenteadministrativatipo cfat ON cfa.tipo = cfat.t_id 
        JOIN {esquema}.cca_destinacioneconomicatipo cdet ON cp.destinacion_economica = cdet.t_id 
        GROUP BY 
            cp.qr_operacion, cp.qr_operacion_definitivo, ccp.ilicode, cp.t_id,ccp.ilicode,cfat.ilicode,cfa.ente_emisor, cfa.numero_fuente,cfa.fecha_documento_fuente,cfa.t_id,cfat.t_id
    ),
    mtj_data AS (
        SELECT 
            local_id AS "QR_MATRIZ (CODIGO_NIVEL) MTJ", 
            id_operacion AS "QR_DERIVADO (ID_OPERACION) MTJ", 
            condicion_predio AS "CONDICION_PREDIO_MTJ", 
            tipo_fuente_adm AS "TIPO FUENTE ADMINISTRATIVA MTJ",
            fmi_ente_emisor AS "ENTE EMISOR FUENTE ADMINISTRATIVA MTJ",
            numero_fuente_adm AS "NÚMERO FUENTE ADMINISTRATIVA MTJ",
            fmi_fecha_documento_fuente AS  "FECHA FUENTE ADMINISTRATIVA MTJ",
            CASE
                WHEN tipo_fuente_adm = 'Sin_Documento' THEN (SELECT t_id FROM {esquema}.cca_fuenteadministrativatipo WHERE ilicode = 'Sin_Documento')
                WHEN tipo_fuente_adm = 'Documento_Publico.Escritura_Publica' THEN (SELECT t_id FROM {esquema}.cca_fuenteadministrativatipo WHERE ilicode = 'Documento_Publico.Escritura_Publica')
                WHEN tipo_fuente_adm = 'Documento_Privado' THEN (SELECT t_id FROM {esquema}.cca_fuenteadministrativatipo WHERE ilicode = 'Documento_Privado')
                WHEN tipo_fuente_adm = 'Documento_Publico.Sentencia_Judicial' THEN (SELECT t_id FROM {esquema}.cca_fuenteadministrativatipo WHERE ilicode = 'Documento_Publico.Sentencia_Judicial')
                WHEN tipo_fuente_adm = 'Documento_Publico.Acto_Administrativo' THEN (SELECT t_id FROM {esquema}.cca_fuenteadministrativatipo WHERE ilicode = 'Documento_Publico.Acto_Administrativo')
                ELSE NULL
            END AS "HOMOLOGACION_TIPO_FUENTE_MTJ"
        FROM mtj.matriz_mtj
    )
    SELECT 
        bd."QR_MATRIZ (CODIGO_NIVEL) BD", 
        bd."QR_DERIVADO (ID_OPERACION) BD",
        bd."CONDICION_PREDIO_BD",
        bd."T_ID CCA_FUENTEADM BD",
        bd."T_ID_TIPO_FUENTE BD" as "T_ID DOMINIO TIPO FUENTE BD",
        bd."TIPO FUENTE ADMINISTRATIVA BD",
        bd."ENTE EMISOR FUENTE ADMINISTRATIVA BD",
        bd."NÚMERO FUENTE ADMINISTRATIVA BD",
        bd."FECHA FUENTE ADMINISTRATIVA BD",
        mtj."QR_MATRIZ (CODIGO_NIVEL) MTJ",
        mtj."QR_DERIVADO (ID_OPERACION) MTJ", 	
        mtj."TIPO FUENTE ADMINISTRATIVA MTJ",
        mtj."ENTE EMISOR FUENTE ADMINISTRATIVA MTJ",
        mtj."NÚMERO FUENTE ADMINISTRATIVA MTJ",
        mtj."FECHA FUENTE ADMINISTRATIVA MTJ",
        CASE
            WHEN mtj."TIPO FUENTE ADMINISTRATIVA MTJ" = 'Sin_Documento' 
            THEN (select t_id
                        from {esquema}.cca_fuenteadministrativatipo 
                        where ilicode='Sin_Documento')
                
            WHEN mtj."TIPO FUENTE ADMINISTRATIVA MTJ" = 'Documento_Publico.Escritura_Publica' 
            THEN (select t_id
                        from {esquema}.cca_fuenteadministrativatipo 
                        where ilicode='Documento_Publico.Escritura_Publica')

            WHEN mtj."TIPO FUENTE ADMINISTRATIVA MTJ" = 'Documento_Privado' 
            THEN (select t_id
                        from {esquema}.cca_fuenteadministrativatipo 
                        where ilicode='Documento_Privado')
            
            WHEN mtj."TIPO FUENTE ADMINISTRATIVA MTJ" = 'Documento_Publico.Sentencia_Judicial' 
            THEN (select t_id
                        from {esquema}.cca_fuenteadministrativatipo 
                        where ilicode='Documento_Publico.Sentencia_Judicial')
            
            WHEN mtj."TIPO FUENTE ADMINISTRATIVA MTJ" = 'Documento_Publico.Acto_Administrativo' 
            THEN (select t_id
                        from {esquema}.cca_fuenteadministrativatipo 
                        where ilicode='Documento_Publico.Acto_Administrativo')
                
            ELSE NULL
        END AS "HOMOLOGACION TIPO_FUENTE MTJ",

        CASE 
            WHEN bd."TIPO FUENTE ADMINISTRATIVA BD" = mtj."TIPO FUENTE ADMINISTRATIVA MTJ" THEN 'SI' 
            WHEN bd."TIPO FUENTE ADMINISTRATIVA BD" IS NULL OR mtj."TIPO FUENTE ADMINISTRATIVA MTJ" IS NULL THEN 'FALTAN DATOS'
            ELSE 'NO' 
        END AS "COINCIDE(SI/NO) TIPO_FUENTE_ADM",	
        
        CASE 
            WHEN bd."ENTE EMISOR FUENTE ADMINISTRATIVA BD" = mtj."ENTE EMISOR FUENTE ADMINISTRATIVA MTJ" 
            OR (bd."ENTE EMISOR FUENTE ADMINISTRATIVA BD" IS NULL AND mtj."ENTE EMISOR FUENTE ADMINISTRATIVA MTJ" IN ('NA','N/A','na','n/a','N/R',''))
            OR (bd."ENTE EMISOR FUENTE ADMINISTRATIVA BD" IN ('NA','N/A','na','n/a','N/R','') AND mtj."ENTE EMISOR FUENTE ADMINISTRATIVA MTJ" IS NULL)
            OR (bd."ENTE EMISOR FUENTE ADMINISTRATIVA BD" IN ('NA','N/A','na','n/a','N/R','') AND mtj."ENTE EMISOR FUENTE ADMINISTRATIVA MTJ" IN ('NA','N/A','na','n/a','N/R',''))
            OR (bd."ENTE EMISOR FUENTE ADMINISTRATIVA BD" IS NULL AND mtj."ENTE EMISOR FUENTE ADMINISTRATIVA MTJ" IS NULL) THEN 'SI' 
            ELSE 'NO' 
        END AS "COINCIDE(SI/NO) ENTE_EMISOR_FUENTE_ADM",	
        CASE 
            WHEN bd."NÚMERO FUENTE ADMINISTRATIVA BD"= mtj."NÚMERO FUENTE ADMINISTRATIVA MTJ" 
            OR (bd."NÚMERO FUENTE ADMINISTRATIVA BD" IS NULL AND mtj."NÚMERO FUENTE ADMINISTRATIVA MTJ" IN ('NA','N/A','N/R','na','n/a',''))
            OR (bd."NÚMERO FUENTE ADMINISTRATIVA BD" IN ('NA','N/A','N/R','na','n/a','') AND mtj."NÚMERO FUENTE ADMINISTRATIVA MTJ" IN ('NA','N/A','N/R','na','n/a',''))
            OR (bd."NÚMERO FUENTE ADMINISTRATIVA BD" IS NULL AND mtj."NÚMERO FUENTE ADMINISTRATIVA MTJ" IS NULL)
            OR (bd."NÚMERO FUENTE ADMINISTRATIVA BD" IN ('NA','N/A','na','N/R','n/a','N/R','') AND mtj."NÚMERO FUENTE ADMINISTRATIVA MTJ" IS NULL) THEN 'SI' 

            ELSE 'NO' 
        END AS "COINCIDE(SI/NO) NUMERO_FUENTE_ADM",	
        CASE 
            WHEN mtj."HOMOLOGACION_TIPO_FUENTE_MTJ" IS NOT NULL AND bd."T_ID CCA_FUENTEADM BD" IS NOT NULL
            THEN 'UPDATE cambiar_esquema.cca_fuenteadministrativa SET tipo =' || mtj."HOMOLOGACION_TIPO_FUENTE_MTJ" || ' WHERE t_id =' || bd."T_ID CCA_FUENTEADM BD"
            ELSE NULL
        END AS "consulta_cambio_tipo_fuente"

    FROM bd_data bd
    FULL OUTER JOIN mtj_data mtj 
    ON bd."QR_DERIVADO (ID_OPERACION) BD" = mtj."QR_DERIVADO (ID_OPERACION) MTJ"
    WHERE bd."QR_DERIVADO (ID_OPERACION) BD" IS NOT NULL OR mtj."QR_DERIVADO (ID_OPERACION) MTJ" IS NOT NULL
    order by bd."T_ID CCA_FUENTEADM BD"

    """,
    
    """
    -- 20 - Verificacón de los dominios de condicion de predio existentes en la BD
    
	SELECT cpt.ilicode AS condicion_predio, COUNT(*) AS total
	FROM {esquema}.cca_predio pd
	JOIN {esquema}.cca_condicionprediotipo cpt ON pd.condicion_predio = cpt.t_id
	GROUP BY  cpt.ilicode
     
    """,
    
    """
	--- 20 verificar dominios de informal_forml en MTJ
 
	SELECT formal_informal, COUNT(*) AS total
	FROM mtj.matriz_mtj
    GROUP BY formal_informal    
    
    """,
    """
    ---  20.1 - Cantidad de formales según columna BP(formal_informal) coincide MTJ - BD
    
    WITH condicion_predio_count AS (
        SELECT 
            cpt.ilicode AS condicion_predio, 
            COUNT(*) AS total_count
        FROM 
            {esquema}.cca_predio pd
        JOIN 
            {esquema}.cca_condicionprediotipo cpt 
            ON pd.condicion_predio = cpt.t_id
        WHERE 
            cpt.ilicode = 'NPH'
        GROUP BY  
            cpt.ilicode
    ),
    formal_informal_count AS (
        SELECT 
            'Total Formal' AS formal_informal, 
            SUM(total) AS total_count
        FROM (
            SELECT 
                formal_informal, 
                COUNT(*) AS total
            FROM 
                mtj.matriz_mtj
            WHERE 
                formal_informal IN ('Formal', 'Formal-sin remanente', 'Formal-con remanente')
            GROUP BY 
                formal_informal
        ) sub
    ),
    default_condicion_predio AS (
        SELECT 0 AS total_count
    )
    SELECT 
        COALESCE(condicion_predio_count.total_count, default_condicion_predio.total_count) AS formales_BD,
        formal_informal_count.total_count AS formales_MTJ,
        CASE 
            WHEN COALESCE(condicion_predio_count.total_count, default_condicion_predio.total_count) = formal_informal_count.total_count THEN 'COINCIDE'
            ELSE 'INCONSISTENCIA'
        END AS comparacion
    FROM 
        formal_informal_count
    LEFT JOIN 
        condicion_predio_count ON TRUE
    LEFT JOIN
        default_condicion_predio ON condicion_predio_count.total_count IS NULL;

    """,
    """

    ---  20.1 REPORTE DE LOS CASOS QUE DIFIEREN FORMALES DE MTJ Y BASE DE DATOS 
    
    WITH cca_predio_data AS (
        SELECT 
            pd.qr_operacion_definitivo,
            CASE
                WHEN cpt.ilicode = 'NPH' THEN 'Formal' ELSE 'Informal' 
            END AS formal_informal_bd
        FROM 
            {esquema}.cca_predio pd
        JOIN 
            {esquema}.cca_condicionprediotipo cpt 
            ON pd.condicion_predio = cpt.t_id
        WHERE 
            cpt.ilicode = 'NPH'
    ),
    matriz_mtj_data AS (
        SELECT 
            id_operacion AS qr_operacion_definitivo,
            CASE 
                WHEN formal_informal IN ('Formal', 'Formal-sin remanente', 'Formal-con remanente') THEN 'Formal' ELSE 'Informal' 
            END AS formal_informal_mtj
        FROM  
            mtj.matriz_mtj
        WHERE 
            formal_informal IN ('Formal', 'Formal-sin remanente', 'Formal-con remanente')
    )
    SELECT 
        COALESCE(cca_predio_data.qr_operacion_definitivo, matriz_mtj_data.qr_operacion_definitivo) AS "QR_DERIVADO (ID_OPERACION)",
        cca_predio_data.formal_informal_bd AS "PREDIO  (FORMAL INFORMAL) BD",
        matriz_mtj_data.formal_informal_mtj AS "PREDIO  (FORMAL INFORMAL) MTJ",
        CASE 
            WHEN cca_predio_data.qr_operacion_definitivo IS NULL THEN 'NO, Falta en cca_predio o mal catalogado'
            WHEN matriz_mtj_data.qr_operacion_definitivo IS NULL THEN 'NO, Falta en matriz_mtj mal catalogado'
            WHEN cca_predio_data.formal_informal_bd = matriz_mtj_data.formal_informal_mtj THEN 'SI'
            ELSE 'INCONSISTENCIA'
        END AS "COINCIDE(SI/NO)"
    FROM 
        cca_predio_data
    FULL OUTER JOIN 
        matriz_mtj_data 
        ON cca_predio_data.qr_operacion_definitivo = matriz_mtj_data.qr_operacion_definitivo;


    """,
    """
    ---20.2  cantidad de informales en la base de datos y MTJ

    WITH condicion_predio_count AS (
        SELECT 
            cpt.ilicode AS condicion_predio, 
            COUNT(*) AS total_count
        FROM 
            {esquema}.cca_predio pd
        JOIN 
            {esquema}.cca_condicionprediotipo cpt 
            ON pd.condicion_predio = cpt.t_id
        WHERE 
            cpt.ilicode = 'Informal'
        GROUP BY  
            cpt.ilicode
    ),
    formal_informal_count AS (
        SELECT 
            'Total Formal' AS formal_informal, 
            SUM(total) AS total_count
        FROM (
            SELECT 
                formal_informal, 
                COUNT(*) AS total
            FROM 
                mtj.matriz_mtj
            WHERE 
                formal_informal IN ('Informal')
            GROUP BY 
                formal_informal
        ) sub
    ),
    default_condicion_predio AS (
        SELECT 0 AS total_count
    )
    SELECT 
        COALESCE(condicion_predio_count.total_count, default_condicion_predio.total_count) AS informales_BD,
        formal_informal_count.total_count AS informales_MTJ,
        CASE 
            WHEN COALESCE(condicion_predio_count.total_count, default_condicion_predio.total_count) = formal_informal_count.total_count THEN 'COINCIDE'
            ELSE 'INCONSISTENCIA'
        END AS comparacion
    FROM 
        formal_informal_count
    LEFT JOIN 
        condicion_predio_count ON TRUE
    LEFT JOIN
        default_condicion_predio ON condicion_predio_count.total_count IS NULL;


    """,
    """

    ---20.2 REPORTE DE LOS CASOS QUE DIFIEREN INFORMALES DE MTJ Y BASE DE DATOS

    WITH cca_predio_data AS (
        SELECT 
            pd.qr_operacion_definitivo,
            CASE
                WHEN cpt.ilicode = 'Informal' THEN 'Informal' ELSE 'Formal' 
            END AS formal_informal_bd
        FROM 
            {esquema}.cca_predio pd
        JOIN 
            {esquema}.cca_condicionprediotipo cpt 
            ON pd.condicion_predio = cpt.t_id
        WHERE 
            cpt.ilicode = 'Informal'
    ),
    matriz_mtj_data AS (
        SELECT 
            id_operacion AS qr_operacion_definitivo,
            CASE 
                WHEN formal_informal IN ('Informal') THEN 'Informal' ELSE 'Formal' 
            END AS formal_informal_mtj
        FROM  
            mtj.matriz_mtj
        WHERE 
            formal_informal IN ('Informal')
    )
    SELECT 
        COALESCE(cca_predio_data.qr_operacion_definitivo, matriz_mtj_data.qr_operacion_definitivo) AS "QR_DERIVADO (ID_OPERACION)",
        cca_predio_data.formal_informal_bd as "PREDIO  (FORMAL INFORMAL) BD",
        matriz_mtj_data.formal_informal_mtj as "PREDIO  (FORMAL INFORMAL) MTJ",
        CASE 
            WHEN cca_predio_data.qr_operacion_definitivo IS NULL THEN 'NO, Falta en cca_predio o mal catalogado'
            WHEN matriz_mtj_data.qr_operacion_definitivo IS NULL THEN 'NO, Falta en matriz_mtj o mal catalogado'
            WHEN cca_predio_data.formal_informal_bd = matriz_mtj_data.formal_informal_mtj THEN 'SI'
            ELSE 'INCONSISTENCIA'
        END AS "COINCIDE(SI/NO)"
    FROM 
        cca_predio_data
    FULL OUTER JOIN 
        matriz_mtj_data 
        ON cca_predio_data.qr_operacion_definitivo = matriz_mtj_data.qr_operacion_definitivo;
 
    
    """,
    """
    --- 20.3 - Verificación de los dominios de condición del predio en la MTJ
    
 	SELECT condicion_predio,COUNT(*) AS total
	FROM mtj.matriz_mtj
    GROUP BY condicion_predio   
    
    
    """,
    """
    ---- QR que les falta dilienciar condicion del predio en MTJ
				
    SELECT id_operacion, condicion_predio from mtj.matriz_mtj  where condicion_predio is NULL
    
    """,
    """
    --- 20.3	cantidad de formales coincide  Base de Datos - MTJ (según columna BT de condicion del predio catalogados como NPH)
    
    WITH condicion_predio_count AS (
        SELECT 
            cpt.ilicode AS condicion_predio, 
            COUNT(*) AS total_count
        FROM 
            {esquema}.cca_predio pd
        JOIN 
            {esquema}.cca_condicionprediotipo cpt 
            ON pd.condicion_predio = cpt.t_id
        WHERE 
            cpt.ilicode = 'NPH'
        GROUP BY  
            cpt.ilicode
    ),
    formal_informal_count AS (
        SELECT 
            'Total Formal' AS formal_informal, 
            SUM(total) AS total_count
        FROM (
            SELECT 
                condicion_predio, 
                COUNT(*) AS total
            FROM 
                mtj.matriz_mtj
            WHERE 
                condicion_predio IN ('NPH')
            GROUP BY 
                condicion_predio
        ) sub
    ),
    default_condicion_predio AS (
        SELECT 0 AS total_count
    )
    SELECT 
        COALESCE(condicion_predio_count.total_count, default_condicion_predio.total_count) AS NPH_BD,
        formal_informal_count.total_count AS NPH_MTJ,
        CASE 
            WHEN COALESCE(condicion_predio_count.total_count, default_condicion_predio.total_count) = formal_informal_count.total_count THEN 'COINCIDE'
            ELSE 'INCONSISTENCIA'
        END AS comparacion
    FROM 
        formal_informal_count
    LEFT JOIN 
        condicion_predio_count ON TRUE
    LEFT JOIN
        default_condicion_predio ON condicion_predio_count.total_count IS NULL;

    
    
    """,
    """

    ---20.3 REPORTE formales Base de Datos - MTJ (según columna BT de condicion del predio catalogados como NPH)

    WITH cca_predio_data AS (
        SELECT 
            pd.qr_operacion_definitivo,
            CASE
                WHEN cpt.ilicode = 'NPH' THEN 'NPH' ELSE 'Informal' 
            END AS condicion_predio_bd
        FROM 
            {esquema}.cca_predio pd
        JOIN 
            {esquema}.cca_condicionprediotipo cpt 
            ON pd.condicion_predio = cpt.t_id
        WHERE 
            cpt.ilicode = 'NPH'
    ),
    matriz_mtj_data AS (
        SELECT 
            id_operacion AS qr_operacion_definitivo,
            CASE 
                WHEN condicion_predio IN ('NPH') THEN 'NPH' ELSE 'Informal' 
            END AS condicion_predio_mtj
        FROM  
            mtj.matriz_mtj
        WHERE 
            condicion_predio IN ('NPH')
    )
    SELECT 
        COALESCE(cca_predio_data.qr_operacion_definitivo, matriz_mtj_data.qr_operacion_definitivo) AS "QR_DERIVADO (ID_OPERACION)",
        cca_predio_data.condicion_predio_bd as "CONDICIÓN PREDIO BD",
        matriz_mtj_data.condicion_predio_mtj as "CONDICIÓN PREDIO MTJ",
        CASE 
            WHEN cca_predio_data.qr_operacion_definitivo IS NULL THEN 'NO, Falta en cca_predio o mal catalogado'
            WHEN matriz_mtj_data.qr_operacion_definitivo IS NULL THEN 'NO, Falta en matriz_mtj mal catalogado'
            WHEN cca_predio_data.condicion_predio_bd = matriz_mtj_data.condicion_predio_mtj THEN 'SI'
            ELSE 'INCONSISTENCIA'
        END AS "COINCIDE(SI/NO)"
    FROM 
        cca_predio_data
    FULL OUTER JOIN 
        matriz_mtj_data 
        ON cca_predio_data.qr_operacion_definitivo = matriz_mtj_data.qr_operacion_definitivo;   
    
    
    """,
    
    """
    
    ---- 20.4 - Cantidad de informales coincide  Base de Datos - MTJ (según columna BT de condicion del predio catalogados como Informales)"
    
    WITH condicion_predio_count AS (
        SELECT 
            cpt.ilicode AS condicion_predio, 
            COUNT(*) AS total_count
        FROM 
            {esquema}.cca_predio pd
        JOIN 
            {esquema}.cca_condicionprediotipo cpt 
            ON pd.condicion_predio = cpt.t_id
        WHERE 
            cpt.ilicode = 'Informal'
        GROUP BY  
            cpt.ilicode
    ),
    formal_informal_count AS (
        SELECT 
            'Total Formal' AS formal_informal, 
            SUM(total) AS total_count
        FROM (
            SELECT 
                condicion_predio, 
                COUNT(*) AS total
            FROM 
                mtj.matriz_mtj
            WHERE 
                condicion_predio IN ('Informal')
            GROUP BY 
                condicion_predio
        ) sub
    ),
    default_condicion_predio AS (
        SELECT 0 AS total_count
    )
    SELECT 
        COALESCE(condicion_predio_count.total_count, default_condicion_predio.total_count) AS Informal_BD,
        formal_informal_count.total_count AS Informal_MTJ,
        CASE 
            WHEN COALESCE(condicion_predio_count.total_count, default_condicion_predio.total_count) = formal_informal_count.total_count THEN 'COINCIDE'
            ELSE 'INCONSISTENCIA'
        END AS comparacion
    FROM 
        formal_informal_count
    LEFT JOIN 
        condicion_predio_count ON TRUE
    LEFT JOIN
        default_condicion_predio ON condicion_predio_count.total_count IS NULL;
   
    """,
    
    """
    --20.4 REPORTE informales Base de Datos - MTJ (según columna BT de condicion del predio catalogados como informal)

    WITH cca_predio_data AS (
        SELECT 
            pd.qr_operacion_definitivo,
            CASE
                WHEN cpt.ilicode = 'Informal' THEN 'Informal' ELSE 'NPH' 
            END AS condicion_predio_bd
        FROM 
            {esquema}.cca_predio pd
        JOIN 
            {esquema}.cca_condicionprediotipo cpt 
            ON pd.condicion_predio = cpt.t_id
        WHERE 
            cpt.ilicode = 'Informal'
    ),
    matriz_mtj_data AS (
        SELECT 
            id_operacion AS qr_operacion_definitivo,
            CASE 
                WHEN condicion_predio IN ('Informal') THEN 'Informal' ELSE 'NPH' 
            END AS condicion_predio_mtj
        FROM  
            mtj.matriz_mtj
        WHERE 
            condicion_predio IN ('Informal')
    )
    SELECT 
        COALESCE(cca_predio_data.qr_operacion_definitivo, matriz_mtj_data.qr_operacion_definitivo) AS "QR_DERIVADO (ID_OPERACION)",
        cca_predio_data.condicion_predio_bd AS "CONDICIÓN PREDIO BD",
        matriz_mtj_data.condicion_predio_mtj AS "CONDICIÓN PREDIO MTJ",
        CASE 
            WHEN cca_predio_data.qr_operacion_definitivo IS NULL THEN 'NO, Falta en cca_predio o mal catalogado'
            WHEN matriz_mtj_data.qr_operacion_definitivo IS NULL THEN 'NO, Falta en matriz_mtj o mal catalogado'
            WHEN cca_predio_data.condicion_predio_bd = matriz_mtj_data.condicion_predio_mtj THEN 'SI'
            ELSE 'INCONSISTENCIA'
        END AS "COINCIDE(SI/NO)"
    FROM 
        cca_predio_data
    FULL OUTER JOIN 
        matriz_mtj_data 
        ON cca_predio_data.qr_operacion_definitivo = matriz_mtj_data.qr_operacion_definitivo;

   
    """,
    """

    ---20.5	Informal tenga el mismo matriz tanto en Base de Datos como MTJ

    WITH cca_predio_data AS (
        SELECT 
            qr_operacion,
            qr_operacion_definitivo,
            qr_operacion || '-' || qr_operacion_definitivo AS concatenado_bd
        FROM 
            {esquema}.cca_predio
    ),
    matriz_mtj_data AS (
        SELECT 
            local_id,
            id_operacion,
            local_id || '-' || id_operacion AS concatenado_mtj
        FROM 
            mtj.matriz_mtj
    )
    SELECT 
        cca_predio_data.qr_operacion AS "QR_MATRIZ (CODIGO_NIVEL) BD", 
        cca_predio_data.qr_operacion_definitivo AS "QR_DERIVADO (ID_OPERACION) BD",
        cca_predio_data.concatenado_bd AS "UNION_BD",
        matriz_mtj_data.local_id AS "QR_MATRIZ (CODIGO_NIVEL) MTJ",
        matriz_mtj_data.id_operacion AS "QR_DERIVADO (ID_OPERACION) MTJ",
        matriz_mtj_data.concatenado_mtj AS "UNION_MTJ",
        CASE 
            WHEN cca_predio_data.concatenado_bd = matriz_mtj_data.concatenado_mtj THEN 'SI'
            ELSE 'NO COINCIDE MATRIZ'
        END AS "COINCIDE(SI/NO)"
    FROM 
        cca_predio_data
    LEFT JOIN 
        matriz_mtj_data 
        ON cca_predio_data.qr_operacion_definitivo = matriz_mtj_data.id_operacion;


   
    """,
    """

    ---- 21.la cantidad de dominios, posesiones y ocupaciones debe se igual en MTJ (COLUMNA BS) y BD

        WITH primera_consulta AS (
            SELECT drt.ilicode as derecho_tipo, COUNT(*) as cuenta_derecho_bd
            FROM {esquema}.cca_predio pd
            JOIN {esquema}.cca_derecho dr ON pd.t_id = dr.predio
            JOIN {esquema}.cca_derechotipo drt ON dr.tipo = drt.t_id
            GROUP BY drt.ilicode
        ),
        segunda_consulta AS (
            SELECT 
                CASE
                    WHEN tipo_derecho IN ('Ocupación', 'Ocupacion', 'ocupacion', 'ocupación') THEN 'Ocupacion'
                    WHEN tipo_derecho IN ('Posesión', 'Posesion', 'posesion', 'posesión') THEN 'Posesion'
                    WHEN tipo_derecho IN ('Dominio', 'dominio') THEN 'Dominio'
                    ELSE 'PEND'
                END AS tipo_der,
                COUNT(*) as cuenta_derecho_mtj
            FROM mtj.matriz_mtj
            GROUP BY tipo_der
        )
        SELECT 
            pc.derecho_tipo as "TIPO DERECHO BD",
            pc.cuenta_derecho_bd AS "CANTIDAD BD",
            sc.tipo_der AS "TIPO DERECHO MTJ",
            sc.cuenta_derecho_mtj AS "CANTIDAD MTJ",
            CASE 
                WHEN pc.cuenta_derecho_bd = sc.cuenta_derecho_mtj THEN 'SI'
                ELSE 'NO, DIFIERE'
            END AS "COINCIDE (SI/NO)"
        FROM primera_consulta pc
        FULL OUTER JOIN segunda_consulta sc
        ON pc.derecho_tipo = sc.tipo_der
        ORDER BY pc.derecho_tipo, sc.tipo_der;


    """,
    """
    -----  21.1 REPORTE DOMINIOS QUE COINCIDEN O DIFIEREN

    WITH primera_consulta AS (
        SELECT qr_operacion, qr_operacion_definitivo, drt.ilicode as derecho_tipo
        FROM {esquema}.cca_predio pd
        JOIN {esquema}.cca_derecho dr ON pd.t_id = dr.predio
        JOIN {esquema}.cca_derechotipo drt ON dr.tipo = drt.t_id
        WHERE drt.ilicode = 'Dominio'
    ),

    segunda_consulta AS (
        SELECT local_id, id_operacion,
            CASE
                WHEN tipo_derecho IN ('Ocupación', 'Ocupacion', 'ocupacion', 'ocupación') THEN 'Ocupacion'
                WHEN tipo_derecho IN ('Posesión', 'Posesion', 'posesion', 'posesión') THEN 'Posesion'
                WHEN tipo_derecho IN ('Dominio', 'dominio','Dominio.PROPIEDAD_COLECTIVA_DE_PUEBLO_O_COMUNIDAD_ETNICA') THEN 'Dominio'
                ELSE 'SIN DEFINICION'
            END AS tipo_der
        FROM mtj.matriz_mtj
        WHERE tipo_derecho IN ('Dominio', 'dominio')
    )
    SELECT 
        pc.qr_operacion AS "QR_MATRIZ (CODIGO_NIVEL) BD",
        pc.qr_operacion_definitivo AS "QR_DERIVADO (ID_OPERACION) BD",
        pc.derecho_tipo AS "TIPO DERECHO BD",
        sc.local_id AS "QR_MATRIZ (CODIGO_NIVEL) MTJ",
        sc.id_operacion AS "QR_DERIVADO (ID_OPERACION) MTJ",
        sc.tipo_der  AS "TIPO DERECHO MTJ",
        CASE 
            WHEN pc.qr_operacion_definitivo IS NULL THEN 'NO, FALTA EN CCA_PREDIO O MAL DILIGENCIADO'
            WHEN sc.id_operacion IS NULL THEN 'NO, FALTA EN MTJ O MAL DILIGENCIADO'
            WHEN pc.derecho_tipo = sc.tipo_der THEN 'SI'
            ELSE 'NO, AJUSTAR'
        END AS "COINCIDE(SI/NO)"
    FROM primera_consulta pc
    FULL OUTER JOIN segunda_consulta sc
    ON pc.qr_operacion_definitivo = sc.id_operacion
    ORDER BY pc.qr_operacion, sc.id_operacion;
        
    
    """,
    """

    --- 21.2   REPORTE POSESIONES QUE COINCIDEN O NO

    WITH primera_consulta AS (
        SELECT qr_operacion, qr_operacion_definitivo, drt.ilicode as derecho_tipo
        FROM {esquema}.cca_predio pd
        JOIN {esquema}.cca_derecho dr ON pd.t_id = dr.predio
        JOIN {esquema}.cca_derechotipo drt ON dr.tipo = drt.t_id
        WHERE drt.ilicode = 'Posesion'
    ),

    segunda_consulta AS (
        SELECT local_id, id_operacion,
            CASE
                WHEN tipo_derecho IN ('Ocupación', 'Ocupacion', 'ocupacion', 'ocupación') THEN 'Ocupacion'
                WHEN tipo_derecho IN ('Posesión', 'Posesion', 'posesion', 'posesión') THEN 'Posesion'
                WHEN tipo_derecho IN ('Dominio', 'dominio') THEN 'Dominio'
                ELSE 'PEND'
            END AS tipo_der
        FROM mtj.matriz_mtj
        WHERE tipo_derecho IN ('Posesión', 'Posesion', 'posesion', 'posesión')
    )
    SELECT 
        pc.qr_operacion AS "QR_MATRIZ (CODIGO_NIVEL) BD",
        pc.qr_operacion_definitivo  AS "QR_DERIVADO (ID_OPERACION)BD",
        pc.derecho_tipo AS "TIPO DERECHO BD",
        sc.local_id "QR_MATRIZ (CODIGO_NIVEL) MTJ",
        sc.id_operacion  AS "QR_DERIVADO (ID_OPERACION) MTJ",
        sc.tipo_der AS "TIPO DERECHO MTJ",
        CASE 
            WHEN pc.qr_operacion_definitivo IS NULL THEN 'NO, FALTA EN CCA_PREDIO O MAL DILIGENCIADO'
            WHEN sc.id_operacion IS NULL THEN 'NO, FALTA EN MTJ O MAL DILIGENCIADO'
            WHEN pc.derecho_tipo = sc.tipo_der THEN 'SI'
            ELSE 'NO, AJUSTAR'
        END AS "COINCIDE(SI/NO)"
    FROM primera_consulta pc
    FULL OUTER JOIN segunda_consulta sc
    ON pc.qr_operacion_definitivo = sc.id_operacion
    ORDER BY pc.qr_operacion, sc.id_operacion;


    """,
    """

    --- 21.3   REPORTE OCUPACIONES QUE COINCIDEN O NO

    WITH primera_consulta AS (
        SELECT qr_operacion, qr_operacion_definitivo, drt.ilicode as derecho_tipo
        FROM {esquema}.cca_predio pd
        JOIN {esquema}.cca_derecho dr ON pd.t_id = dr.predio
        JOIN {esquema}.cca_derechotipo drt ON dr.tipo = drt.t_id
        WHERE drt.ilicode = 'Ocupacion'
    ),

    segunda_consulta AS (
        SELECT local_id, id_operacion,
            CASE
                WHEN tipo_derecho IN ('Ocupación', 'Ocupacion', 'ocupacion', 'ocupación') THEN 'Ocupacion'
                WHEN tipo_derecho IN ('Posesión', 'Posesion', 'posesion', 'posesión') THEN 'Posesion'
                WHEN tipo_derecho IN ('Dominio', 'dominio') THEN 'Dominio'
                ELSE 'PEND'
            END AS tipo_der
        FROM mtj.matriz_mtj
        WHERE tipo_derecho IN ('Ocupación', 'Ocupacion', 'ocupacion', 'ocupación')
    )
    SELECT 
        pc.qr_operacion AS "QR_MATRIZ (CODIGO_NIVEL) BD",
        pc.qr_operacion_definitivo  AS "QR_DERIVADO (ID_OPERACION) BD",
        pc.derecho_tipo AS "TIPO DERECHO BD",
        sc.local_id "QR_MATRIZ (CODIGO_NIVEL) MTJ",
        sc.id_operacion  AS "QR_DERIVADO (ID_OPERACION) MTJ",
        sc.tipo_der AS "TIPO DERECHO MTJ",
        CASE 
            WHEN pc.qr_operacion_definitivo IS NULL THEN 'NO, FALTA EN CCA_PREDIO O MAL DILIGENCIADO'
            WHEN sc.id_operacion IS NULL THEN 'NO, FALTA EN MTJ O MAL DILIGENCIADO'
            WHEN pc.derecho_tipo = sc.tipo_der THEN 'SI'
            ELSE 'NO, AJUSTAR'
        END AS "COINCIDE(SI/NO)"
    FROM primera_consulta pc
    FULL OUTER JOIN segunda_consulta sc
    ON pc.qr_operacion_definitivo = sc.id_operacion
    ORDER BY pc.qr_operacion, sc.id_operacion;

    """,
    """

    --- 22.1- Coincidencia de los QR tanto en MTJ como en BD

    WITH primera_consulta AS (
        SELECT qr_operacion, qr_operacion_definitivo
        FROM {esquema}.cca_predio pd
    ),
    segunda_consulta AS (
        SELECT local_id, id_operacion
        FROM mtj.matriz_mtj
    )
    SELECT 
        pc.qr_operacion AS "QR_MATRIZ (CODIGO_NIVEL) BD",
        pc.qr_operacion_definitivo  AS "QR_DERIVADO (ID_OPERACION) BD",
        sc.local_id "QR_MATRIZ (CODIGO_NIVEL) MTJ",
        sc.id_operacion  AS "QR_DERIVADO (ID_OPERACION) MTJ",
        CASE 
            WHEN pc.qr_operacion_definitivo IS NULL THEN 'NO, FALTA EN CCA_PREDIO O MAL DILIGENCIADO'
            WHEN sc.id_operacion IS NULL THEN 'NO, FALTA EN MTJ O MAL DILIGENCIADO'
            WHEN pc.qr_operacion_definitivo = sc.id_operacion THEN 'SI'
            ELSE 'NO, AJUSTAR'
        END AS "COINCIDE(SI/NO)"
    FROM primera_consulta pc
    FULL OUTER JOIN segunda_consulta sc
    ON pc.qr_operacion_definitivo = sc.id_operacion
    ORDER BY pc.qr_operacion, sc.id_operacion;

    """,
    """
    ---- 22.2	Coincidencia de los numeros prediales tanto en MTJ como en BD
    
    WITH primera_consulta AS (
        SELECT t_id, qr_operacion, qr_operacion_definitivo, numero_predial
        FROM {esquema}.cca_predio
    ),

    segunda_consulta AS (
        SELECT 
            id, local_id, 
            id_operacion, 
            numero_predial, 
            numero_predial_provisional,tipo_novedad,
            CASE 
                WHEN numero_predial_provisional IS NULL THEN numero_predial
                WHEN LENGTH(numero_predial_provisional) >= 18 AND SUBSTRING(numero_predial_provisional FROM 18 FOR 1) SIMILAR TO '[A-Za-z]' THEN numero_predial_provisional
                WHEN numero_predial_provisional SIMILAR TO '%[^[:alnum:][:space:]]%'  THEN numero_predial
                ELSE numero_predial_provisional
            END AS PREDIAL_DEF
        FROM 
            mtj.matriz_mtj	
    )
    SELECT
        pc.t_id as "T_ID BD",
        pc.qr_operacion AS "QR_MATRIZ (CODIGO_NIVEL) BD",
        pc.qr_operacion_definitivo  AS "QR_DERIVADO (ID_OPERACION) BD",
        pc.numero_predial AS "NUMERO_PREDIAL_BD",
        sc.id as "ID MTJ",
        sc.local_id "QR_MATRIZ (CODIGO_NIVEL) MTJ",
        sc.id_operacion  AS "QR_DERIVADO (ID_OPERACION)MTJ",
        sc.numero_predial as "NUMERO PREDIAL VIGENTE",
        sc.numero_predial_provisional as "NUMERO PREDIAL (PROVISIONAL)",
        sc.tipo_novedad as "TIPO DE NOVEDAD NÚMERO PREDIAL (MODELO LADM)",
        sc.PREDIAL_DEF AS "TOTALES PREDIALES_MTJ",
        CASE 
            WHEN pc.qr_operacion_definitivo IS NULL THEN 'NO, FALTA EN CCA_PREDIO O MAL DILIGENCIADO'
            WHEN sc.id_operacion IS NULL THEN 'NO, FALTA EN MTJ O MAL DILIGENCIADO'
            WHEN pc.numero_predial = sc.PREDIAL_DEF THEN 'SI'
            ELSE 'NO, AJUSTAR Ó ACTUALIZAR A NPN PROVISIONAL'
        END AS "COINCIDE(SI/NO)",

        CASE 
            WHEN pc.numero_predial IS NOT NULL AND sc.PREDIAL_DEF IS NOT NULL
            THEN 'UPDATE cambiar_esquema.cca_predio SET numero_predial =' || sc.PREDIAL_DEF || ' WHERE t_id =' || pc.t_id
            ELSE NULL
        END AS "CONSULTA_PARA ACT_NPN"        
        
    FROM primera_consulta pc
    FULL OUTER JOIN segunda_consulta sc
    ON pc.qr_operacion_definitivo = sc.id_operacion
    ORDER BY pc.qr_operacion, sc.id_operacion;


    """,
    """

    --- 22.3	Si tipo de novedad numero predial es Predio_Nuevo, entonces debe tener numero provisional asignado en la MTJ

    SELECT
        id as "ID",
        local_id as "QR_MATRIZ (CODIGO_NIVEL)", 
        id_operacion as "QR_DERIVADO(ID_OPERACION)", 
        numero_predial as "NUMERO PREDIAL VIGENTE", 
        numero_predial_provisional as "NUMERO PREDIAL (PROVISIONAL)",tipo_novedad as "TIPO DE NOVEDAD NÚMERO PREDIAL (MODELO LADM)",  'VERIFICAR,FALTA PREDIAL PROVISIONAL' as "VALIDACION"
    FROM mtj.matriz_mtj		
    WHERE tipo_novedad ='Predio_Nuevo' and numero_predial_provisional is null
    or  tipo_novedad ='Predio_Nuevo' and numero_predial_provisional SIMILAR TO '%[^[:alnum:][:space:]]%'

    """,
    """

    -----22.4.1  REPETICIONES FORMALES SOBRE LA BASE  DE DATOS
    
    SELECT 
        numero_predial,
        CONDICION_PREDIO,
        STRING_AGG(qr_operacion_definitivo, ', ') AS qr_operacion_definitivo_afectados,
        repeticiones, 'VERIFIFCAR, UN NUMERO PREDIAL SOLO DEBE ESTAR ASOCIADO A 1 QR FORMAL' as validacion
    FROM 
        (SELECT 
            pd.numero_predial,
            pd.qr_operacion_definitivo,
            cpt.ilicode as CONDICION_PREDIO,
            COUNT(*) OVER (PARTITION BY pd.numero_predial) AS repeticiones
        FROM 
            {esquema}.cca_predio pd
        JOIN 
            {esquema}.cca_condicionprediotipo cpt ON pd.condicion_predio = cpt.t_id
        WHERE 
            cpt.ilicode = 'NPH'
        ) AS subquery
    WHERE 
        repeticiones > 1
    GROUP BY 
        numero_predial, CONDICION_PREDIO, repeticiones;


    """,
    """
    ------22.4.2  REPETICIONES FORMALES SOBRE MTJ

    SELECT 
        numero_predial,
        STRING_AGG(id_operacion::text, ', ') AS qr_operacion_definitivo_afectados,
        STRING_AGG(CONDICION_PREDIO, ', ') AS tipo_formal_asociados,
        repeticiones, 'VERIFIFCAR, UN NUMERO PREDIAL SOLO DEBE ESTAR ASOCIADO A 1 QR FORMAL' as validacion
    FROM 
        (SELECT 
            pd.numero_predial,
            pd.id_operacion,
            pd.formal_informal AS CONDICION_PREDIO,
            COUNT(*) OVER (PARTITION BY pd.numero_predial) AS repeticiones
        FROM 
            mtj.matriz_mtj pd
        WHERE 
            pd.formal_informal IN ('Formal', 'Formal-sin remanente', 'Formal-con remanente')
        ) AS subquery
    WHERE 
        repeticiones > 1
    GROUP BY 
        numero_predial, repeticiones;


    """,
    """

    ---- QR REPETIDOS EN MTJ
    
    select id,id_operacion, count(id_operacion) as repetidos 
    from mtj.matriz_mtj
    group by id, id_operacion
    HAVING count(id_operacion) > 1


    """,
    """
    ---- reporte 1 intereados 
    
    WITH interesados_bd AS (

            SELECT 
                pd.qr_operacion_definitivo,
                STRING_AGG(int.ilicode, ',') AS interesados_tipo_bd,
                STRING_AGG(indt.ilicode, ',') AS interesados_documentotipo_bd,
                STRING_AGG(i.documento_identidad, ',') AS interesados_documento_bd,
                STRING_AGG(
                    CASE 
                        WHEN indt.ilicode = 'NIT' THEN i.razon_social
                        ELSE CONCAT(i.primer_nombre, ' ', i.segundo_nombre, ' ', i.primer_apellido, ' ', i.segundo_apellido)
                    END, 
                    ','
                ) AS interesados_bd
            FROM 
                {esquema}.cca_predio pd
            JOIN 
                {esquema}.cca_derecho dr ON pd.t_id = dr.predio
            JOIN 
                {esquema}.cca_interesado i ON dr.t_id = i.derecho
            JOIN 
                {esquema}.cca_interesadotipo int ON i.tipo = int.t_id
            JOIN
                {esquema}.cca_interesadodocumentotipo indt ON i.tipo_documento = indt.t_id
            GROUP BY 
                pd.qr_operacion_definitivo
        ),
        comparisons AS (
            SELECT 
                mtj.id_operacion,
                mtj.condicion_predio,
                mtj."CR_InteresadoTipo" AS "Interesa_Tipo_MTJ",
                ibd.interesados_tipo_bd AS "Interesa_Tipo_BD",    
                CASE 
                    WHEN ARRAY(SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(mtj."CR_InteresadoTipo", '\s+', '', 'g')), ',')) ORDER BY 1) = ARRAY(SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(ibd.interesados_tipo_bd, '\s+', '', 'g')), ',')) ORDER BY 1) THEN 'SI' 
                    ELSE 'NO' 
                END AS "COINCIDEN(SI/NO) TIPO_INT",
                
                mtj."CR_DocumentoTipo" AS "Documento_Tipo_MTJ",
                ibd.interesados_documentotipo_bd AS "Documento_Tipo_BD",
                CASE 
                    WHEN ARRAY(SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(mtj."CR_DocumentoTipo", '\s+', '', 'g')), ',')) ORDER BY 1) = ARRAY(SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(ibd.interesados_documentotipo_bd, '\s+', '', 'g')), ',')) ORDER BY 1) THEN 'SI' 
                    ELSE 'NO' 
                END AS "COINCIDEN(SI/NO) DOC_TIPO",    
                
                mtj."Documento_Identidad" AS "Num_Documento_MTJ",
                ibd.interesados_documento_bd AS "Num_Documento_BD",    
                CASE 
                    WHEN ARRAY(SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(mtj."Documento_Identidad", '\s+', '', 'g')), ',')) ORDER BY 1) = ARRAY(SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(ibd.interesados_documento_bd, '\s+', '', 'g')), ',')) ORDER BY 1) THEN 'SI' 
                    ELSE 'NO' 
                END AS "COINCIDEN(SI/NO) NUMERO_DOC_ID",        
                
                mtj."CR_Interesado_all" AS "Interesados_MTJ",
                ibd.interesados_bd AS "Interesados_BD",
                CASE 
                    WHEN ARRAY(
                            SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(unaccent(UPPER(mtj."CR_Interesado_all")), '\s+', '', 'g')), ',')) 
                            ORDER BY 1
                        ) = ARRAY(
                            SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(unaccent(UPPER(ibd.interesados_bd)), '\s+', '', 'g')), ',')) 
                            ORDER BY 1
                        ) THEN 'SI' 
                    ELSE 'NO' 
                END AS "COINCIDEN(SI/NO) NOMBRE_INTERESADOS",
                ARRAY(
                    SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(unaccent(UPPER(mtj."CR_Interesado_all")), '\s+', '', 'g')), ',')) 
                    EXCEPT 
                    SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(unaccent(UPPER(ibd.interesados_bd)), '\s+', '', 'g')), ',')) 
                ) AS "DIFERENCIAS_INTERESADOS_MTJ",
                ARRAY(
                    SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(unaccent(UPPER(ibd.interesados_bd)), '\s+', '', 'g')), ',')) 
                    EXCEPT 
                    SELECT UNNEST(STRING_TO_ARRAY(TRIM(regexp_replace(unaccent(UPPER(mtj."CR_Interesado_all")), '\s+', '', 'g')), ',')) 
                ) AS "DIFERENCIAS_INTERESADOS_BD"


            FROM 
                mtj.matriz_mtj mtj
            LEFT JOIN 
                interesados_bd ibd ON mtj.id_operacion = ibd.qr_operacion_definitivo

        )
        SELECT 
            *
        FROM comparisons;  



    """,
    """
    ---24.1 - El campo tiene_construcciones debe estar diligenciado

    SELECT id, local_id, id_operacion, tiene_construcciones
    FROM mtj.matriz_mtj
    WHERE tiene_construcciones IS NULL 
    OR tiene_construcciones = '' 
    OR tiene_construcciones = '0';

    """,
    """
    -- 24.2	El campo "tipo novedad numero predial" debe estar diligenciado

    SELECT id, local_id, id_operacion, tipo_novedad
    FROM mtj.matriz_mtj
    WHERE tipo_novedad IS NULL 
    OR tipo_novedad = '' 
    OR tipo_novedad = '0';
        

    """,

    """
    ---24.3	El campo "Predio formal informal" debe estar diligenciado

    
    SELECT id, local_id, id_operacion, formal_informal
    FROM mtj.matriz_mtj
    WHERE formal_informal IS NULL 
    OR formal_informal = '' 
    OR formal_informal = '0';    

    """,

    """
    ----24.4	El campo "Naturaleza predio" debe estar dilifenciado


    SELECT id, local_id, id_operacion, naturaleza_predio
    FROM mtj.matriz_mtj
    WHERE naturaleza_predio IS NULL 
    OR naturaleza_predio = '' 
    OR naturaleza_predio = '0';


    """,
    """
    --- 24.5	El campo "Tipo predio" debe estar diligenciado

    SELECT id, local_id, id_operacion, tipo_predio
    FROM mtj.matriz_mtj
    WHERE tipo_predio IS NULL 
    OR tipo_predio = '' 
    OR tipo_predio = '0'; 



    """,
    """
    ---24.6	El campo "Tipo derecho" debe estar diligenciado

    SELECT id, local_id, id_operacion, tipo_derecho
    FROM mtj.matriz_mtj
    WHERE tipo_derecho IS NULL 
    OR tipo_derecho = '' 
    OR tipo_derecho = '0';


    """,
    """
    -- 24.7	El capo "Condicion predio" debe estar diligenciado

        
    SELECT id, local_id, id_operacion, condicion_predio
    FROM mtj.matriz_mtj
    WHERE condicion_predio IS NULL 
    OR condicion_predio = '' 
    OR condicion_predio = '0';
    
    
    """
    


    
        
    


]

nombres_consultas_observaciones_mtj = [
    "18.1 - Area  de Levantamiento en Base de datos coincide con area MTJ",
    "18.2 - Area  y numero de construcciones coincide Base de Datos  MTJ",
    "19 - Coindicencia Fuente administrativa Base de Datos - MTJ",
    "20 - Verificacón dominios de condicion de predio s en la BD",
    "20 - Verificacón los dominios de formal/informal  en la MTJ",
    "20.1 - Cantidad de formales según columna BP(formal_informal) coincide MTJ - BD",
    "20.1 - Reporte de formales que coinciden o no según columna BP(formal_informal) MTJ - BD",
    "20.2 - Cantidad de infformales según columna BP(formal_informal) coincide MTJ - BD",
    "20.2 - Reporte de informales que coinciden o no según columna BP(formal_informal) MTJ - BD",
    "20.3 - Verificación de los dominios de condición del predio en la MTJ",
    "20.3 - QR que les falta diligenciar la condición del predio en la MTJ",
    "20.3 - Cantidad de formales coincide  Base de Datos - MTJ (según columna BT de condicion del predio catalogados como NPH)",
    "20.3 - Reporte formales coincide o no Base de Datos - MTJ (según columna BT de condicion del predio catalogados como NPH)",
    "20.4 - Cantidad de informales coincide  Base de Datos - MTJ (según columna BT de condicion del predio catalogados como Informales)",
    "20.4 - Reporte informales coincide o no Base de Datos - MTJ (según columna BT de condicion del predio catalogados como Informales)",
    "20.5 - Informal tenga el mismo matriz tanto en Base de Datos como MTJ",
    "21 - la cantidad de dominios, posesiones y ocupaciones debe se igual en MTJ (COLUMNA BS) y BD",
    "21.1 - REPORTE DOMINIOS QUE COINCIDEN O DIFIEREN",
    "21.2 - REPORTE POSESIONES QUE COINCIDEN O NO",
    "21.3 - REPORTE OCUPACIONES QUE COINCIDEN O NO",
    "22.1 - Coincidencia de los QR definitivos tanto en MTJ como en BD",
    "22.2 - Coincidencia de los numeros prediales tanto en MTJ como en BD",
    "22.3	Si tipo de novedad numero predial es Predio_Nuevo, entonces debe tener numero provisional asignado en la MTJ",
    "22.4.1 - No pueden haber formalidades con un mismo número predial en BD",
    "22.4.1 - No pueden haber formalidades con un mismo número predial en MTJ",
    "Verificación QR Definitivos repetidos en MTJ",
    "23.1 Los diferentes QR deben tener correspondencia de los interesados tanto en MTJ como en la base de datos",
    "24.1 - El campo tiene_construcciones debe estar diligenciado",
    "24.2 - El campo tipo_novedad numero predial debe estar diligenciado",
    "24.3 - El campo Predio_formal informal debe estar diligenciado",
    "24.4 - El campo Naturaleza_predio debe estar dilifenciado",
    "24.5 - El campo Tipo_predio debe estar diligenciado",
    "24.6	El campo Tipo_derecho debe estar diligenciado",
    "24.7	El capo Condicion_predio debe estar diligenciado",

    

    
    

]
