def classFactory(iface):
    from .xy import XYPlugin
    return XYPlugin(iface)
