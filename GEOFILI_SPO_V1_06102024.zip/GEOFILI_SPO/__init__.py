def classFactory(iface):
    from .JM_TOOLS import JM_TOOLS
    return JM_TOOLS(iface)
